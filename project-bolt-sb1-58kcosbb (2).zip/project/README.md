# Mason Crest AI

Transform your business with Intelligent Automation Solutions.

## About

Mason Crest AI specializes in intelligent automation solutions including:
- Workflow Automation
- Agentic AI Systems  
- Conversational AI (Chatbots & Phone Callers)
- Custom Integrations

## Tech Stack

- **Frontend**: React 18 with TypeScript
- **Styling**: Tailwind CSS
- **Routing**: React Router DOM
- **Icons**: Lucide React
- **Font**: Oswald (Google Fonts)
- **Build Tool**: Vite

## Getting Started

### Prerequisites
- Node.js (v18 or higher)
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone <your-repo-url>
cd mason-crest-ai
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open [http://localhost:5173](http://localhost:5173) to view it in the browser.

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint

## Features

- **Responsive Design**: Optimized for all device sizes
- **Modern UI**: Clean, professional design with smooth animations
- **Interactive Chatbot**: AI-powered customer support
- **Contact Forms**: Integrated with webhook automation
- **SEO Optimized**: Proper meta tags and semantic HTML

## Deployment

The site is configured for deployment on Netlify and other static hosting platforms.

## Contact

- Email: contactmasoncrest@gmail.com
- LinkedIn: [Jack Mason](https://www.linkedin.com/in/jack-mason-a99a5537a/)

## License

© 2025 Mason Crest AI. All rights reserved.