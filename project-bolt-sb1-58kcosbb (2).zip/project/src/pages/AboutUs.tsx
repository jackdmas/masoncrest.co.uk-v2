import React from 'react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Users, Target, Award, Lightbulb } from 'lucide-react';
import Header from '../components/Header';
import LogoModal from '../components/LogoModal';

const AboutUs: React.FC = () => {
  const [isLogoModalOpen, setIsLogoModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      
      {/* Hero Section */}
      <section className="px-6 py-24 sm:py-40 pt-40 bg-gray-800">
        <div className="max-w-5xl mx-auto flex flex-col items-center">
          <Link 
            to="/" 
            className="inline-flex items-center text-gray-200 hover:text-white mb-12 transition-colors duration-300 text-lg"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Home
          </Link>
          
          <div className="text-center mb-20 w-full flex flex-col items-center">
            <img 
              src="/image copy.png" 
              alt="Mason Crest AI Logo" 
              className="w-20 h-20 mb-8 cursor-pointer hover:scale-110 transition-transform duration-300 rounded-xl mx-auto"
              onClick={() => setIsLogoModalOpen(true)}
            />
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white tracking-tight text-center mb-12">
              About Mason Crest AI
            </h1>
            <p className="text-xl sm:text-2xl text-gray-300 leading-relaxed max-w-4xl mx-auto text-center">
              Pioneering the future of intelligent automation with cutting-edge AI solutions that transform businesses worldwide.
            </p>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="px-6 py-24 bg-gray-300">
        <div className="max-w-7xl mx-auto flex flex-col items-center">
          <div className="grid lg:grid-cols-2 gap-20 items-center">
            <div>
              <h2 className="text-4xl sm:text-5xl font-bold text-black mb-8">
                Our Mission
              </h2>
              <p className="text-lg text-gray-600 leading-relaxed mb-8">
                At Mason Crest AI, we believe that intelligent automation should empower businesses to achieve unprecedented efficiency and innovation. Our mission is to democratize AI technology, making it accessible and practical for organizations of all sizes.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                We're committed to delivering solutions that not only automate processes but also enhance human capabilities, creating a synergy between artificial intelligence and human expertise.
              </p>
            </div>
            <div className="bg-gray-100 p-10 rounded-2xl shadow-lg border border-gray-400">
              <h3 className="text-3xl font-bold text-black mb-8">Our Core Values</h3>
              <div className="space-y-8">
                <div className="flex items-start">
                  <div className="bg-gray-700 p-3 rounded-2xl w-12 h-12 mr-6 flex items-center justify-center flex-shrink-0">
                    <Lightbulb className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-black mb-3">Innovation</h4>
                    <p className="text-gray-600 leading-relaxed">
                      Constantly pushing the boundaries of what's possible with AI technology.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-gray-700 p-3 rounded-2xl w-12 h-12 mr-6 flex items-center justify-center flex-shrink-0">
                    <Users className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-black mb-3">Collaboration</h4>
                    <p className="text-gray-600 leading-relaxed">
                      Working closely with clients to understand and solve their unique challenges.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-gray-700 p-3 rounded-2xl w-12 h-12 mr-6 flex items-center justify-center flex-shrink-0">
                    <Award className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-black mb-3">Excellence</h4>
                    <p className="text-gray-600 leading-relaxed">
                      Delivering the highest quality solutions with meticulous attention to detail.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-gray-700 p-3 rounded-2xl w-12 h-12 mr-6 flex items-center justify-center flex-shrink-0">
                    <Target className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-black mb-3">Results</h4>
                    <p className="text-gray-600 leading-relaxed">
                      Focusing on measurable outcomes that drive real business value.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>



      {/* CTA Section */}
      <section className="px-6 py-24 bg-gray-800">
        <div className="max-w-5xl mx-auto text-center flex flex-col items-center">
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-8">
            Ready to Work Together?
          </h2>
          <p className="text-xl text-gray-200 mb-12 leading-relaxed max-w-4xl mx-auto text-center">
            Let's discuss how Mason Crest AI can help transform your business with intelligent automation.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center w-full">
            <Link 
              to="/solutions"
             className="inline-flex items-center px-10 py-4 bg-gray-700 text-gray-100 font-medium rounded-full border-2 border-gray-300 hover:bg-gray-100 hover:text-gray-800 transition-all duration-300 shadow-lg hover:shadow-xl group"
            >
              Explore Our Solutions
              <ArrowLeft className="w-5 h-5 ml-3 rotate-180 group-hover:translate-x-1 transition-transform duration-300" />
            </Link>
            <Link 
              to="/contact"
             className="inline-flex items-center px-10 py-4 bg-gray-700 text-gray-100 font-medium rounded-full border-2 border-gray-300 hover:bg-gray-100 hover:text-gray-800 transition-all duration-300 shadow-lg hover:shadow-xl"
            >
              Contact Us Today
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-6 py-16 bg-gray-700">
        <div className="max-w-7xl mx-auto text-center flex flex-col items-center">
          <div className="flex items-center justify-center mb-8">
            <img 
              src="/image copy.png" 
              alt="Mason Crest AI Logo" 
              className="w-10 h-10 mr-4 cursor-pointer hover:scale-110 transition-transform duration-300 rounded-lg"
              onClick={() => setIsLogoModalOpen(true)}
            />
            <span className="text-3xl font-bold text-white">Mason Crest AI</span>
          </div>
          <p className="text-gray-300 text-lg">
            © 2025 Mason Crest AI. All rights reserved.
          </p>
        </div>
      </footer>
      
      <LogoModal 
        isOpen={isLogoModalOpen} 
        onClose={() => setIsLogoModalOpen(false)} 
      />
    </div>
  );
};

export default AboutUs;