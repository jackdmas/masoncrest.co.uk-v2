import React from 'react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Workflow, Zap, ArrowRight, Bot, Notebook as Robot, Sparkles } from 'lucide-react';
import Header from '../components/Header';
import LogoModal from '../components/LogoModal';
import Chatbot from '../components/Chatbot';

const Home: React.FC = () => {
  const [isLogoModalOpen, setIsLogoModalOpen] = useState(false);
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      
      {/* Hero Section */}
      <section className="px-6 py-24 sm:py-40 pt-40 bg-gray-800">
        <div className="max-w-6xl mx-auto text-center flex flex-col items-center">
          <img 
            src="/image copy.png" 
            alt="Mason Crest AI Logo" 
            className="w-24 h-24 mb-8 cursor-pointer hover:scale-110 transition-all duration-500 drop-shadow-xl rounded-2xl mx-auto"
            onClick={() => setIsLogoModalOpen(true)}
          />
          <h1 className="text-6xl sm:text-7xl lg:text-8xl font-bold text-white tracking-tight leading-none mb-16 text-center">
            Mason Crest AI
          </h1>
          
          {/* Subheading */}
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-light text-gray-200 mb-20 max-w-5xl mx-auto leading-relaxed text-center">
            Transform your business with Intelligent Automation
          </h2>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center w-full">
            <Link 
              to="/about"
              className="inline-flex items-center px-10 py-4 bg-gray-700 text-gray-100 font-medium rounded-full border-2 border-gray-300 hover:bg-gray-100 hover:text-gray-800 transition-all duration-300 shadow-lg hover:shadow-xl group"
            >
              About Us
              <ArrowRight className="w-5 h-5 ml-3 group-hover:translate-x-1 transition-transform duration-300" />
            </Link>
            <Link 
              to="/solutions"
              className="inline-flex items-center px-10 py-4 bg-gray-700 text-gray-100 font-medium rounded-full border-2 border-gray-300 hover:bg-gray-100 hover:text-gray-800 transition-all duration-300 shadow-lg hover:shadow-xl group"
            >
              Solutions & Services
              <ArrowRight className="w-5 h-5 ml-3 group-hover:translate-x-1 transition-transform duration-300" />
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="px-6 py-24 bg-gray-300">
        <div className="max-w-7xl mx-auto flex flex-col items-center">
          <div className="text-center mb-20 w-full">
            <h2 className="text-4xl sm:text-5xl font-bold text-black mb-6">
              Our Solutions
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed text-center">
              Comprehensive AI-powered solutions designed to transform your business operations
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 lg:gap-12 w-full max-w-6xl mx-auto">
            
            {/* Feature 1: Workflow Automation */}
            <div className="bg-gray-100 rounded-2xl p-8 shadow-lg border border-gray-400 hover:shadow-xl transition-all duration-500 group hover:-translate-y-2 flex flex-col items-center text-center">
              <div className="bg-gray-700 p-6 rounded-2xl w-20 h-20 mb-8 flex items-center justify-center group-hover:bg-gray-600 transition-all duration-300">
                <Workflow className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-black mb-6">
                Workflow Automation
              </h3>
              <p className="text-gray-600 leading-relaxed text-lg">
                Simplify repetitive tasks and streamline your operations with intelligent workflow solutions.
              </p>
            </div>

            {/* Feature 2: Agentic AI */}
            <div className="bg-gray-100 rounded-2xl p-8 shadow-lg border border-gray-400 hover:shadow-xl transition-all duration-500 group hover:-translate-y-2 flex flex-col items-center text-center">
              <div className="bg-gray-700 p-6 rounded-2xl w-20 h-20 mb-8 flex items-center justify-center group-hover:bg-gray-600 transition-all duration-300">
                <Robot className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-black mb-6">
                Agentic AI
              </h3>
              <p className="text-gray-600 leading-relaxed text-lg">
                Deploy intelligent systems that act autonomously to drive results and optimize performance.
              </p>
            </div>

            {/* Feature 3: Custom Integrations */}
            <div className="bg-gray-100 rounded-2xl p-8 shadow-lg border border-gray-400 hover:shadow-xl transition-all duration-500 group hover:-translate-y-2 flex flex-col items-center text-center">
              <div className="bg-gray-700 p-6 rounded-2xl w-20 h-20 mb-8 flex items-center justify-center group-hover:bg-gray-600 transition-all duration-300">
                <Zap className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-black mb-6">
                Custom Integrations
              </h3>
              <p className="text-gray-600 leading-relaxed text-lg">
                Tailored AI solutions seamlessly integrated with your existing business infrastructure.
              </p>
            </div>

          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="px-6 py-24 bg-gray-800">
        <div className="max-w-5xl mx-auto text-center flex flex-col items-center">
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-8">
            Ready to Transform Your Business?
          </h2>
          <p className="text-xl text-gray-200 mb-12 leading-relaxed max-w-4xl mx-auto text-center">
            Discover how Mason Crest AI can revolutionize your operations with cutting-edge automation solutions.
          </p>
          <Link 
            to="/contact"
            className="inline-flex items-center px-12 py-5 bg-gray-700 text-gray-100 font-medium rounded-full border-2 border-gray-300 hover:bg-gray-100 hover:text-gray-800 transition-all duration-300 shadow-lg hover:shadow-xl group text-lg"
          >
            Contact Us
            <ArrowRight className="w-6 h-6 ml-3 group-hover:translate-x-1 transition-transform duration-300" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-6 py-16 bg-gray-700">
        <div className="max-w-7xl mx-auto text-center flex flex-col items-center">
          <div className="flex items-center justify-center mb-8">
            <img 
              src="/image copy.png" 
              alt="Mason Crest AI Logo" 
              className="w-10 h-10 mr-4 cursor-pointer hover:scale-110 transition-transform duration-300 rounded-lg"
              onClick={() => setIsLogoModalOpen(true)}
            />
            <span className="text-3xl font-bold text-white">Mason Crest AI</span>
          </div>
          <p className="text-gray-300 text-lg">
            © 2025 Mason Crest AI. All rights reserved.
          </p>
        </div>
      </footer>
      
      <LogoModal 
        isOpen={isLogoModalOpen} 
        onClose={() => setIsLogoModalOpen(false)} 
      />
      
      {/* Chatbot Button */}
      {!isChatbotOpen && (
        <button
          onClick={() => setIsChatbotOpen(true)}
          className="fixed bottom-6 left-6 bg-gray-700 hover:bg-gray-100 hover:text-gray-800 text-gray-100 px-6 py-4 rounded-full border-2 border-gray-500 hover:border-gray-400 shadow-xl transition-all duration-300 flex items-center space-x-3 z-40 group"
        >
          <div className="bg-gray-100 text-gray-800 p-2 rounded-xl group-hover:bg-gray-700 group-hover:text-gray-100 transition-all duration-300">
            <Bot className="w-5 h-5" />
          </div>
          <span className="font-medium text-lg">Any questions right now? Ask our AI Chatbot</span>
        </button>
      )}
      
      <Chatbot 
        isOpen={isChatbotOpen} 
        onClose={() => setIsChatbotOpen(false)} 
      />
    </div>
  );
};

export default Home;