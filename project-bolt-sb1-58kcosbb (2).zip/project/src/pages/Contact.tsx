import React from 'react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Mail, Phone, MapPin, Linkedin } from 'lucide-react';
import Header from '../components/Header';
import LogoModal from '../components/LogoModal';

const Contact: React.FC = () => {
  const [isLogoModalOpen, setIsLogoModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    emailAddress: '',
    interestOfContact: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.fullName.trim() || !formData.emailAddress.trim() || !formData.interestOfContact.trim()) {
      return;
    }

    setIsSubmitting(true);
    setSubmitStatus('idle');

    try {
      const response = await fetch('https://n8n22.masoncrest.co.uk/webhook/37770ee0-0f4e-46bf-8fc3-91a5ceb9a19f', {
        method: 'POST',
        mode: 'cors',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          full_name: formData.fullName,
          email_address: formData.emailAddress,
          interest_of_contact: formData.interestOfContact,
          timestamp: new Date().toISOString(),
          source: 'mason-crest-ai-contact-form'
        })
      });

      if (response.ok) {
        setSubmitStatus('success');
        // Clear all form fields
        setFormData({
          fullName: '',
          emailAddress: '',
          interestOfContact: ''
        });
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      console.error('Form submission error:', error);
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      
      {/* Hero Section */}
      <section className="px-6 py-24 sm:py-40 pt-40 bg-gray-800">
        <div className="max-w-5xl mx-auto flex flex-col items-center">
          <Link 
            to="/" 
            className="inline-flex items-center text-gray-200 hover:text-white mb-12 transition-colors duration-300 text-lg"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Home
          </Link>
          
          <div className="text-center mb-20 w-full flex flex-col items-center">
            <img 
              src="/image copy.png" 
              alt="Mason Crest AI Logo" 
              className="w-20 h-20 mb-8 cursor-pointer hover:scale-110 transition-transform duration-300 rounded-xl mx-auto"
              onClick={() => setIsLogoModalOpen(true)}
            />
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white tracking-tight text-center mb-12">
              Contact Us
            </h1>
            <p className="text-xl sm:text-2xl text-gray-300 leading-relaxed max-w-4xl mx-auto text-center">
              Ready to transform your business with intelligent automation? Get in touch with our team today.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="px-6 py-24 bg-gray-300">
        <div className="max-w-7xl mx-auto flex flex-col items-center">
          <div className="grid lg:grid-cols-3 gap-10 items-stretch">
            <div className="text-center flex">
              <div className="bg-gray-100 p-10 rounded-2xl shadow-lg border border-gray-400 w-full flex flex-col justify-between min-h-[600px] items-center text-center">
                <div className="bg-gray-700 p-6 rounded-2xl w-20 h-20 mb-8 flex items-center justify-center">
                  <Mail className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-black mb-6">
                  Get In Touch
                </h2>
                <p className="text-gray-600 leading-relaxed mb-8">
                  Have questions about our AI solutions? Want to discuss automation? We'd love to hear from you.
                </p>
                <div className="bg-white p-6 rounded-2xl mb-8 flex-grow flex flex-col justify-center border border-gray-300">
                  <h3 className="text-lg font-bold text-black mb-4">Email Us</h3>
                  <a 
                    href="mailto:contactmasoncrest@gmail.com"
                    className="text-lg text-gray-800 hover:text-gray-600 transition-colors duration-300 font-medium break-all"
                  >
                    contactmasoncrest@gmail.com
                  </a>
                </div>
                <p className="text-gray-500 text-sm mt-auto">
                  Guaranteed response within 24 hours, 7 days a week.
                </p>
              </div>
            </div>
            
            <div className="text-center flex">
              <div className="bg-gray-100 p-10 rounded-2xl shadow-lg border border-gray-400 w-full flex flex-col justify-between min-h-[600px] items-center text-center">
                <div className="bg-gray-700 p-6 rounded-2xl w-20 h-20 mb-8 flex items-center justify-center">
                  <Linkedin className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-black mb-6">
                  Connect on LinkedIn
                </h2>
                <p className="text-gray-600 leading-relaxed mb-8">
                  Connect with founder Jack Mason on LinkedIn for AI automation trends and company updates.
                </p>
                <div className="bg-white p-6 rounded-2xl mb-8 flex-grow flex flex-col justify-center border border-gray-300">
                  <h3 className="text-lg font-bold text-black mb-6">LinkedIn Profile</h3>
                  <a 
                    href="https://www.linkedin.com/in/jack-mason-a99a5537a/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-full transition-all duration-300 shadow-lg hover:shadow-xl border-2 border-blue-600 hover:border-blue-700"
                  >
                    <Linkedin className="w-5 h-5 mr-2" />
                    Connect with Jack Mason
                  </a>
                </div>
                <p className="text-gray-500 text-sm mt-auto">
                  Professional networking and industry insights.
                </p>
              </div>
            </div>
            
            <div className="text-center flex">
              <div className="bg-gray-100 p-10 rounded-2xl shadow-lg border border-gray-400 w-full flex flex-col justify-between min-h-[600px] items-center text-center">
                <div className="bg-gray-700 p-6 rounded-2xl w-20 h-20 mb-8 flex items-center justify-center">
                  <Mail className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-black mb-6">
                  Want us to contact you?
                </h2>
                <p className="text-gray-600 leading-relaxed mb-8">
                  Fill out the form and we'll get back to you within 24 hours to discuss your automation needs.
                </p>
                <form onSubmit={handleSubmit} className="space-y-6 text-left flex-grow flex flex-col w-full">
                  <div>
                    <label className="block text-gray-800 font-bold mb-2">Full Name</label>
                    <input
                      type="text"
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleInputChange}
                      required
                      className="w-full bg-white text-gray-800 placeholder-gray-500 px-4 py-3 rounded-xl border border-gray-400 focus:border-gray-600 focus:outline-none transition-colors duration-300"
                      placeholder="Enter your full name"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-800 font-bold mb-2">Email Address</label>
                    <input
                      type="email"
                      name="emailAddress"
                      value={formData.emailAddress}
                      onChange={handleInputChange}
                      required
                      className="w-full bg-white text-gray-800 placeholder-gray-500 px-4 py-3 rounded-xl border border-gray-400 focus:border-gray-600 focus:outline-none transition-colors duration-300"
                      placeholder="Enter your email address"
                    />
                  </div>
                  <div className="flex-grow flex flex-col">
                    <label className="block text-gray-800 font-bold mb-2">Interest of Contact</label>
                    <textarea
                      rows={4}
                      name="interestOfContact"
                      value={formData.interestOfContact}
                      onChange={handleInputChange}
                      required
                      className="w-full bg-white text-gray-800 placeholder-gray-500 px-4 py-3 rounded-xl border border-gray-400 focus:border-gray-600 focus:outline-none transition-colors duration-300 resize-none flex-grow"
                      placeholder="Tell us about your automation needs or questions..."
                    />
                  </div>
                  
                  {submitStatus === 'success' && (
                    <div className="text-green-600 font-medium text-center">
                      Message sent successfully! We'll get back to you within 24 hours.
                    </div>
                  )}
                  
                  {submitStatus === 'error' && (
                    <div className="text-red-600 font-medium text-center">
                      Failed to send message. Please try again or email us directly.
                    </div>
                  )}
                  
                  <button
                    type="submit"
                    disabled={isSubmitting || !formData.fullName.trim() || !formData.emailAddress.trim() || !formData.interestOfContact.trim()}
                    className="w-full bg-gray-700 hover:bg-gray-600 disabled:bg-gray-400 disabled:text-gray-600 text-white font-medium py-4 rounded-xl transition-all duration-300 shadow-lg hover:shadow-xl mt-auto border-2 border-gray-700 hover:border-gray-600 disabled:border-gray-400"
                  >
                    {isSubmitting ? 'Sending...' : 'Send Message'}
                  </button>
                </form>
                <p className="text-gray-500 text-sm mt-6">
                  We'll respond within 24 hours.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* What to Expect */}
      <section className="px-6 py-24 bg-gray-800">
        <div className="max-w-7xl mx-auto flex flex-col items-center">
          <div className="text-center mb-20 w-full">
            <h2 className="text-4xl sm:text-5xl font-bold text-white mb-8">
              What to Expect
            </h2>
            <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed text-center">
              When you reach out to us, here's what happens next
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-12 w-full max-w-6xl mx-auto">
            <div className="text-center">
              <div className="bg-gray-100 text-gray-800 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold shadow-lg">
                1
              </div>
              <h3 className="text-xl font-bold text-white mb-4">Initial Response</h3>
              <p className="text-gray-200 leading-relaxed">
                We'll respond to your inquiry within 24 hours to schedule a discovery call.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-gray-100 text-gray-800 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold shadow-lg">
                2
              </div>
              <h3 className="text-xl font-bold text-white mb-4">Discovery Call</h3>
              <p className="text-gray-200 leading-relaxed">
                We'll discuss business needs and identify potential implementations.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-gray-100 text-gray-800 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold shadow-lg">
                3
              </div>
              <h3 className="text-xl font-bold text-white mb-4">Custom Proposal</h3>
              <p className="text-gray-200 leading-relaxed">
                Receive a tailored proposal outlining how we can help transform your business.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-6 py-16 bg-gray-700">
        <div className="max-w-7xl mx-auto text-center flex flex-col items-center">
          <div className="flex items-center justify-center mb-8">
            <img 
              src="/image copy.png" 
              alt="Mason Crest AI Logo" 
              className="w-10 h-10 mr-4 cursor-pointer hover:scale-110 transition-transform duration-300 rounded-lg"
              onClick={() => setIsLogoModalOpen(true)}
            />
            <span className="text-3xl font-bold text-white">Mason Crest AI</span>
          </div>
          <p className="text-gray-300 text-lg">
            © 2025 Mason Crest AI. All rights reserved.
          </p>
        </div>
      </footer>
      
      <LogoModal 
        isOpen={isLogoModalOpen} 
        onClose={() => setIsLogoModalOpen(false)} 
      />
    </div>
  );
};

export default Contact;