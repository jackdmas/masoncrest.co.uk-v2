import React from 'react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Workflow, Zap, Bot, Database, ArrowRight, Users } from 'lucide-react';
import Header from '../components/Header';
import LogoModal from '../components/LogoModal';

const Solutions: React.FC = () => {
  const [isLogoModalOpen, setIsLogoModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      
      {/* Hero Section */}
      <section className="px-6 py-24 sm:py-40 pt-40 bg-gray-800">
        <div className="max-w-5xl mx-auto flex flex-col items-center">
          <Link 
            to="/" 
            className="inline-flex items-center text-gray-200 hover:text-white mb-12 transition-colors duration-300 text-lg"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Home
          </Link>
          
          <div className="text-center mb-20 w-full flex flex-col items-center">
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white tracking-tight mb-8">
              Solutions & Services
            </h1>
            <p className="text-xl sm:text-2xl text-gray-300 leading-relaxed max-w-4xl mx-auto text-center">
              Comprehensive AI-powered solutions designed to automate, optimize, and transform your business operations.
            </p>
          </div>
        </div>
      </section>

      {/* Core Solutions */}
      <section className="px-6 py-24 bg-gray-300">
        <div className="max-w-7xl mx-auto flex flex-col items-center">
          <div className="text-center mb-20 w-full">
            <h2 className="text-4xl sm:text-5xl font-bold text-black mb-8">
              Core Solutions
            </h2>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed text-center">
              Our flagship offerings that drive measurable business transformation
            </p>
          </div>
          
          <div className="grid lg:grid-cols-3 gap-10 w-full max-w-6xl mx-auto">
            {/* Workflow Automation */}
            <div className="bg-gray-100 p-10 rounded-2xl shadow-lg border border-gray-400 hover:shadow-xl transition-all duration-500 group hover:-translate-y-2 flex flex-col items-center text-center">
              <div className="bg-gray-700 p-6 rounded-2xl w-20 h-20 mb-8 flex items-center justify-center group-hover:bg-gray-600 transition-all duration-300">
                <Workflow className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-black mb-6">
                Workflow Automation
              </h3>
              <p className="text-gray-600 leading-relaxed mb-8">
                Streamline repetitive tasks and complex business processes with intelligent automation that learns and adapts to your operations.
              </p>
              <ul className="text-gray-600 space-y-3 mb-8">
                <li>• Process mapping and optimization</li>
                <li>• Custom workflow design</li>
                <li>• Integration with existing systems</li>
                <li>• Real-time monitoring and analytics</li>
              </ul>
            </div>

            {/* Agentic AI */}
            <div className="bg-gray-100 p-10 rounded-2xl shadow-lg border border-gray-400 hover:shadow-xl transition-all duration-500 group hover:-translate-y-2 flex flex-col items-center text-center">
              <div className="bg-gray-700 p-6 rounded-2xl w-20 h-20 mb-8 flex items-center justify-center group-hover:bg-gray-600 transition-all duration-300">
                <img 
                  src="/image copy.png" 
                  alt="AI Icon" 
                  className="w-8 h-8 cursor-pointer hover:scale-110 transition-transform duration-300 rounded-lg"
                  onClick={() => setIsLogoModalOpen(true)}
                />
              </div>
              <h3 className="text-2xl font-bold text-black mb-6">
                Agentic AI Systems
              </h3>
              <p className="text-gray-600 leading-relaxed mb-8">
                Deploy autonomous AI agents that make decisions, take actions, and continuously improve performance without human intervention.
              </p>
              <ul className="text-gray-600 space-y-3 mb-8">
                <li>• Autonomous decision-making</li>
                <li>• Multi-agent coordination</li>
                <li>• Continuous learning capabilities</li>
                <li>• Goal-oriented task execution</li>
              </ul>
            </div>

            {/* Custom Integrations */}
            <div className="bg-gray-100 p-10 rounded-2xl shadow-lg border border-gray-400 hover:shadow-xl transition-all duration-500 group hover:-translate-y-2 flex flex-col items-center text-center">
              <div className="bg-gray-700 p-6 rounded-2xl w-20 h-20 mb-8 flex items-center justify-center group-hover:bg-gray-600 transition-all duration-300">
                <Bot className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-black mb-6">
                Conversational AI
              </h3>
              <p className="text-gray-600 leading-relaxed mb-8">
                Deploy intelligent AI chatbots and phone callers that engage customers naturally, handle inquiries 24/7, and provide personalized support experiences.
              </p>
              <ul className="text-gray-600 space-y-3 mb-8">
                <li>• 24/7 customer support automation</li>
                <li>• Natural language understanding</li>
                <li>• Multi-channel deployment (web, phone, SMS)</li>
                <li>• Seamless human handoff when needed</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="px-6 py-24 bg-gray-800">
        <div className="max-w-7xl mx-auto flex flex-col items-center">
          <div className="text-center mb-20 w-full">
            <h2 className="text-4xl sm:text-5xl font-bold text-white mb-8">
              Additional Services
            </h2>
            <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed text-center">
              Comprehensive support services to ensure your AI initiatives succeed
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10 w-full max-w-6xl mx-auto">
            <div className="text-center group">
              <div className="bg-gray-100 p-6 rounded-2xl w-20 h-20 mb-8 flex items-center justify-center group-hover:bg-white transition-all duration-300 mx-auto">
                <Bot className="w-10 h-10 text-gray-800" />
              </div>
              <h3 className="text-xl font-bold text-white mb-6">AI Consulting</h3>
              <p className="text-gray-200 leading-relaxed text-lg">
                Strategic guidance to identify AI opportunities and develop implementation roadmaps.
              </p>
            </div>
            
            <div className="text-center group">
              <div className="bg-gray-100 p-6 rounded-2xl w-20 h-20 mb-8 flex items-center justify-center group-hover:bg-white transition-all duration-300 mx-auto">
                <Database className="w-10 h-10 text-gray-800" />
              </div>
              <h3 className="text-xl font-bold text-white mb-6">Data Analytics</h3>
              <p className="text-gray-200 leading-relaxed text-lg">
                Transform raw data into actionable insights with advanced analytics and visualization.
              </p>
            </div>
            
            <div className="text-center group">
              <div className="bg-gray-100 p-6 rounded-2xl w-20 h-20 mb-8 flex items-center justify-center group-hover:bg-white transition-all duration-300 mx-auto">
                <Users className="w-10 h-10 text-gray-800" />
              </div>
              <h3 className="text-xl font-bold text-white mb-6">Team Training</h3>
              <p className="text-gray-200 leading-relaxed text-lg">
                Comprehensive training programs to help your team leverage AI tools effectively.
              </p>
            </div>
            
            <div className="text-center group">
              <div className="bg-gray-100 p-6 rounded-2xl w-20 h-20 mb-8 flex items-center justify-center group-hover:bg-white transition-all duration-300 mx-auto">
                <ArrowRight className="w-10 h-10 text-gray-800" />
              </div>
              <h3 className="text-xl font-bold text-white mb-6">Ongoing Support</h3>
              <p className="text-gray-200 leading-relaxed text-lg">
                24/7 technical support and maintenance to keep your AI systems running smoothly.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="px-6 py-24 bg-gray-300">
        <div className="max-w-7xl mx-auto flex flex-col items-center">
          <div className="text-center mb-20 w-full">
            <h2 className="text-4xl sm:text-5xl font-bold text-black mb-8">
              Our Process
            </h2>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed text-center">
              A proven methodology that ensures successful AI implementation
            </p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-12 w-full max-w-6xl mx-auto">
            <div className="text-center">
              <div className="bg-gray-700 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold shadow-lg">
                1
              </div>
              <h3 className="text-xl font-bold text-black mb-4">Discovery</h3>
              <p className="text-gray-600 leading-relaxed">
                Understand your business needs and identify automation opportunities.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-gray-700 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold shadow-lg">
                2
              </div>
              <h3 className="text-xl font-bold text-black mb-4">Design</h3>
              <p className="text-gray-600 leading-relaxed">
                Create tailored AI solutions that align with your business objectives.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-gray-700 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold shadow-lg">
                3
              </div>
              <h3 className="text-xl font-bold text-black mb-4">Deploy</h3>
              <p className="text-gray-600 leading-relaxed">
                Implement and integrate solutions with minimal disruption to operations.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-gray-700 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold shadow-lg">
                4
              </div>
              <h3 className="text-xl font-bold text-black mb-4">Optimize</h3>
              <p className="text-gray-600 leading-relaxed">
                Continuously monitor and improve performance for maximum ROI.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-6 py-24 bg-gray-800">
        <div className="max-w-5xl mx-auto text-center flex flex-col items-center">
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-8">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-gray-200 mb-12 leading-relaxed max-w-4xl mx-auto text-center">
            Let's discuss how our solutions can transform your business operations and drive growth.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center w-full">
            <Link 
              to="/contact"
              className="inline-flex items-center px-10 py-4 bg-gray-700 text-gray-100 font-medium rounded-full border-2 border-gray-300 hover:bg-gray-100 hover:text-gray-800 transition-all duration-300 shadow-lg hover:shadow-xl group"
            >
              Contact Us
              <ArrowRight className="w-5 h-5 ml-3 group-hover:translate-x-1 transition-transform duration-300" />
            </Link>
            <Link 
              to="/about"
              className="inline-flex items-center px-10 py-4 bg-gray-700 text-gray-100 font-medium rounded-full border-2 border-gray-300 hover:bg-gray-100 hover:text-gray-800 transition-all duration-300 shadow-lg hover:shadow-xl"
            >
              Learn About Our Team
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-6 py-16 bg-gray-700">
        <div className="max-w-7xl mx-auto text-center flex flex-col items-center">
          <div className="flex items-center justify-center mb-8">
            <img 
              src="/image copy.png" 
              alt="Mason Crest AI Logo" 
              className="w-10 h-10 mr-4 cursor-pointer hover:scale-110 transition-transform duration-300 rounded-lg"
              onClick={() => setIsLogoModalOpen(true)}
            />
            <span className="text-3xl font-bold text-white">Mason Crest AI</span>
          </div>
          <p className="text-gray-300 text-lg">
            © 2025 Mason Crest AI. All rights reserved.
          </p>
        </div>
      </footer>
      
      <LogoModal 
        isOpen={isLogoModalOpen} 
        onClose={() => setIsLogoModalOpen(false)} 
      />
    </div>
  );
};

export default Solutions;