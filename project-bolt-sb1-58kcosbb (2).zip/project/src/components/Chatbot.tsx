import React, { useState, useRef, useEffect } from 'react';
import { Bot, X, Send, Minimize2 } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
}

interface ChatbotProps {
  isOpen: boolean;
  onClose: () => void;
}

const formatMessageText = (text: string) => {
  // First, let's handle line breaks and professional formatting
  const formattedText = text
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0)
    .join('\n');
  
  // Split text by whitespace and punctuation while preserving them
  const parts = formattedText.split(/(\s+|[.,!?;:\n])/);
  
  return parts.map((part, index) => {
    // Handle line breaks
    if (part === '\n') {
      return <br key={index} />;
    }
    
    // Check for URLs (http, https, www)
    const urlRegex = /(https?:\/\/[^\s.,!?;:]+|www\.[^\s.,!?;:]+)/gi;
    if (urlRegex.test(part)) {
      let url = part;
      if (!url.startsWith('http')) {
        url = 'https://' + url;
      }
      return (
        <a
          key={index}
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-400 hover:text-blue-300 underline transition-all duration-200 px-2 py-1 rounded-md border border-blue-400/40 hover:border-blue-300/60 bg-blue-400/15 hover:bg-blue-300/20 font-medium"
        >
          {part}
        </a>
      );
    }
    
    // Check for email addresses
    const emailRegex = /[^\s@]+@[^\s@.,!?;:]+\.[^\s@.,!?;:]+/gi;
    if (emailRegex.test(part)) {
      return (
        <a
          key={index}
          href={`mailto:${part}`}
          className="text-green-400 hover:text-green-300 underline transition-all duration-200 font-medium px-2 py-1 rounded-md border border-green-400/40 hover:border-green-300/60 bg-green-400/15 hover:bg-green-300/20"
        >
          {part}
        </a>
      );
    }
    
    // Check for phone numbers (various formats)
    const phoneRegex = /(\+?1[-.\s]?)?\(?([0-9]{3})\)?[-.\s]?([0-9]{3})[-.\s]?([0-9]{4})|(\+?[1-9]\d{1,14})/;
    if (phoneRegex.test(part.replace(/\s/g, ''))) {
      return (
        <a
          key={index}
          href={`tel:${part.replace(/\s/g, '')}`}
          className="text-yellow-400 hover:text-yellow-300 underline transition-all duration-200 font-medium px-2 py-1 rounded-md border border-yellow-400/40 hover:border-yellow-300/60 bg-yellow-400/15 hover:bg-yellow-300/20"
        >
          {part}
        </a>
      );
    }
    
    // Return regular text
    return <span key={index}>{part}</span>;
  });
};

const Chatbot: React.FC<ChatbotProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hello, Welcome to Mason Crest AI. How can I help you today?",
      isUser: false,
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getAIResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('workflow') || lowerMessage.includes('automation')) {
      return "Our workflow automation solutions help streamline repetitive tasks and optimize business processes. We create custom workflows that integrate with your existing systems and provide real-time monitoring. Would you like to know more about how we can automate your specific processes?";
    }
    
    if (lowerMessage.includes('agentic') || lowerMessage.includes('autonomous')) {
      return "Agentic AI systems are autonomous agents that can make decisions and take actions without human intervention. They continuously learn and adapt to optimize performance. These systems are perfect for complex decision-making processes and goal-oriented tasks. What specific use case are you considering?";
    }
    
    if (lowerMessage.includes('chatbot') || lowerMessage.includes('conversational')) {
      return "We develop intelligent chatbots and phone callers that provide 24/7 customer support with natural language understanding. Our conversational AI can handle inquiries across multiple channels and seamlessly hand off to humans when needed. Are you looking to automate customer support?";
    }
    
    if (lowerMessage.includes('price') || lowerMessage.includes('cost') || lowerMessage.includes('pricing')) {
      return "Our pricing is customized based on your specific needs and project scope. We offer flexible engagement models from consulting to full implementation. I'd recommend contacting our team at contactmasoncrest@gmail.com for a personalized quote. Would you like me to help you identify what solutions might be right for you?";
    }
    
    if (lowerMessage.includes('contact') || lowerMessage.includes('email') || lowerMessage.includes('reach')) {
      return "You can reach our team at contactmasoncrest@gmail.com. We guarantee a response within 24 hours and offer a free discovery call to discuss your automation needs. Would you like me to help you prepare questions for that call?";
    }
    
    if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('hey')) {
      return "Hello! Great to meet you. I'm here to help you learn about Mason Crest AI's intelligent automation solutions. Are you looking to automate specific business processes, or would you like an overview of our capabilities?";
    }
    
    if (lowerMessage.includes('help') || lowerMessage.includes('what can you do')) {
      return "I can help you understand our three core solutions: Workflow Automation (streamlining repetitive tasks), Agentic AI (autonomous decision-making systems), and Conversational AI (chatbots and phone callers). I can also provide information about our consulting services, pricing, and how to get started. What interests you most?";
    }
    
    return "That's a great question! While I can provide information about our workflow automation, agentic AI systems, and conversational AI solutions, I'd recommend reaching out to our team at contactmasoncrest@gmail.com for detailed technical discussions. They can provide personalized guidance based on your specific needs. Is there a particular automation challenge you're facing?";
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      isUser: true,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    const messageText = inputValue;
    setInputValue('');
    setIsTyping(true);
    
    // Send message to webhook and wait for response
    try {
      const response = await fetch('https://n8n22.masoncrest.co.uk/webhook/8422e084-8493-410f-8461-da7a074f937b', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: messageText,
          timestamp: new Date().toISOString(),
          source: 'mason-crest-ai-chatbot'
        })
      });
      
      if (response.ok) {
        const responseData = await response.text();
        
        // Clean the response text - remove quotes, brackets, and extra formatting
        let cleanedResponse = responseData;
        
        // Remove surrounding quotes
        cleanedResponse = cleanedResponse.replace(/^["']|["']$/g, '');
        
        // Remove escaped quotes
        cleanedResponse = cleanedResponse.replace(/\\"/g, '"');
        
        // Remove surrounding brackets/braces
        cleanedResponse = cleanedResponse.replace(/^[\[\{]|[\]\}]$/g, '');
        
        // Try to extract from JSON if it's a JSON response
        try {
          const jsonResponse = JSON.parse(responseData);
          if (typeof jsonResponse === 'string') {
            cleanedResponse = jsonResponse;
          } else if (jsonResponse.text) {
            cleanedResponse = jsonResponse.text;
          } else if (jsonResponse.message) {
            cleanedResponse = jsonResponse.message;
          } else if (jsonResponse.response) {
            cleanedResponse = jsonResponse.response;
          }
        } catch (e) {
          // Not JSON, use cleaned text response
        }
        
        // Final cleanup - remove any remaining quotes and trim
        cleanedResponse = cleanedResponse.replace(/['"]/g, '').trim();
        
        // Remove "output" word and any following colons or spaces
        cleanedResponse = cleanedResponse.replace(/^output\s*:?\s*/i, '');
        
        // Format the text properly - convert JSON formatting to readable text
        cleanedResponse = cleanedResponse
          .replace(/\\n/g, '\n')           // Convert \n to actual line breaks
          .replace(/\\r/g, '\r')           // Convert \r to carriage returns
          .replace(/\\t/g, '\t')           // Convert \t to tabs
          .replace(/\\\\/g, '\\')          // Convert \\ to single backslash
          .replace(/\\"/g, '"')            // Convert \" to regular quotes
          .replace(/\\'/g, "'")            // Convert \' to regular apostrophes
          .replace(/\s+/g, ' ')            // Replace multiple spaces with single space
          .trim()                          // Remove leading/trailing whitespace
          .replace(/\. /g, '.\n');         // Add line breaks after sentences for better formatting
        
        const aiResponse: Message = {
          id: (Date.now() + 1).toString(),
          text: cleanedResponse || 'I received your message but had trouble processing the response. Please try again.',
          isUser: false,
          timestamp: new Date()
        };
        
        setMessages(prev => [...prev, aiResponse]);
      } else {
        // Fallback to local AI response if webhook fails
        const aiResponse: Message = {
          id: (Date.now() + 1).toString(),
          text: getAIResponse(messageText),
          isUser: false,
          timestamp: new Date()
        };
        
        setMessages(prev => [...prev, aiResponse]);
      }
    } catch (error) {
      console.error('Failed to send message to webhook:', error);
      // Fallback to local AI response if webhook fails
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: getAIResponse(messageText),
        isUser: false,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, aiResponse]);
    }
    
    setIsTyping(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-6 left-6 w-96 h-[500px] bg-gray-100 border-2 border-gray-400 rounded-2xl shadow-xl z-50 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-6 border-b border-gray-400">
        <div className="flex items-center">
          <div className="bg-gray-700 p-3 rounded-xl mr-4">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-gray-800 font-bold text-lg">Mason Crest AI Assistant</h3>
            <p className="text-gray-600 text-sm">Online now</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="text-gray-500 hover:text-gray-800 transition-colors duration-300 p-2"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] p-3 rounded-2xl ${
                message.isUser
                  ? 'bg-gray-700 text-white'
                  : 'bg-gray-300 text-gray-800 leading-relaxed'
              }`}
            >
              <p className="text-sm leading-relaxed">
                {message.isUser ? message.text : formatMessageText(message.text)}
              </p>
            </div>
          </div>
        ))}
        
        {messages.length > 1 && (
          <div className="text-center py-2">
            <div className="text-xs text-gray-500">Responses are formatted for clarity</div>
          </div>
        )}
        
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-gray-300 p-3 rounded-2xl">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-gray-600 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-600 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                <div className="w-2 h-2 bg-gray-600 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-6 border-t border-gray-400">
        <div className="flex items-center space-x-3">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask about our AI solutions or services..."
            className="flex-1 bg-white text-gray-800 placeholder-gray-500 px-4 py-3 rounded-xl border border-gray-400 focus:border-gray-600 focus:outline-none transition-colors duration-300"
          />
          <button
            onClick={handleSendMessage}
            disabled={!inputValue.trim()}
           className="bg-gray-700 hover:bg-gray-600 disabled:bg-gray-400 disabled:text-gray-600 text-white p-3 rounded-xl transition-all duration-300 shadow-lg"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Chatbot;