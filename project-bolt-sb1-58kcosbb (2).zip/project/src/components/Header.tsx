import React from 'react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import LogoModal from './LogoModal';

const Header: React.FC = () => {
  const [isLogoModalOpen, setIsLogoModalOpen] = useState(false);

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 bg-gray-200/95 backdrop-blur-sm border-b border-gray-400 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-5">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center">
              <img 
                src="/image copy.png" 
                alt="Mason Crest AI Logo" 
                className="w-10 h-10 mr-4 cursor-pointer hover:scale-110 transition-transform duration-300 rounded-lg"
                onClick={() => setIsLogoModalOpen(true)}
              />
              <Link to="/" className="text-2xl font-bold text-black hover:text-gray-700 transition-colors duration-300">
                Mason Crest AI
              </Link>
            </div>
            
            {/* Navigation */}
            <nav className="hidden md:flex items-center space-x-10">
              <Link 
                to="/" 
                className="text-gray-600 hover:text-gray-800 transition-colors duration-300 font-medium text-lg"
              >
                Home
              </Link>
              <Link 
                to="/about" 
                className="text-gray-600 hover:text-gray-800 transition-colors duration-300 font-medium text-lg"
              >
                About Us
              </Link>
              <Link 
                to="/solutions" 
                className="text-gray-600 hover:text-gray-800 transition-colors duration-300 font-medium text-lg"
              >
                Solutions & Services
              </Link>
              <Link 
                to="/contact" 
                className="text-gray-600 hover:text-gray-800 transition-colors duration-300 font-medium text-lg"
              >
                Contact
              </Link>
            </nav>
            
            {/* Mobile menu button */}
            <button className="md:hidden text-gray-800">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </header>
      
      <LogoModal 
        isOpen={isLogoModalOpen} 
        onClose={() => setIsLogoModalOpen(false)} 
      />
    </>
  );
};

export default Header;